.. _manual-datamodel-domainmodel:

The default domain model
========================


