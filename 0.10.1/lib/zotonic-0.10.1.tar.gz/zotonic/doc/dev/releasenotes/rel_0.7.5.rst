Release 0.7.5
=============

Released on 2012-03-11 09:04 by arjan.


Andreas Stenius (1):

* Fix dialog display issue when not using <html xmlns=...>

Arjan Scherpenisse (7):

* admin: Show error message when user tries to add the same page connection twice.
* LiveValidation: use the same e-mail regexp as in the backend.
* mod_import_wordpress: More feedback, convert text to proper paragraphs, support for 1.1 WXR schema.
* mod_twitter: Fixed converting unicode -> utf-8 in body text of received tweets.
* mod_oauth: Fixed access/request token uris to work with both GET and POST

