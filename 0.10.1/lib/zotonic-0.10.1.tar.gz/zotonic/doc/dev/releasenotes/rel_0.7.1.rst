Release 0.7.1
=============

Released on 2011-08-03 13:17 by arjan.


Arjan

* Documentation fixes and fixed wrapping of homepage links in the www.zotonic.com site
* Fixed the menu editor: Added resource_menu_admin_menu again which was removed by accident.
* Reworked the way mod_logging notifies the log pages; it now uses mod_signal.
* Fixed quality=xx parameter to {% image %}.
* Added mod_signal to the default list of installed modules.
