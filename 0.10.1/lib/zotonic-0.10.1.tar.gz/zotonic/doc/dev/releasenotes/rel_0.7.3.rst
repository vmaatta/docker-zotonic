Release 0.7.3
=============

Released on 2011-12-14 14:43 by arjan.


Arjan Scherpenisse (1):

* Fixed mod_mailinglist compilation error on 0.7.x branch.
