Release 0.1.0
=============

Released on 2009-11-13.

* Initial release.
* Packaged the zotonic.com site as the prime "example" site in the default install.
