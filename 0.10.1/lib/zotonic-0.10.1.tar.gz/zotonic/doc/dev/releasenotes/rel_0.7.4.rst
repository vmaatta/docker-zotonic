Release 0.7.4
=============

Released on 2012-01-10 14:44 by arjan.


Arjan Scherpenisse (1):

* mod_twitter - use https for streaming API.


Marc Worrell (1):

* Fix for pivoting with a new resource.

