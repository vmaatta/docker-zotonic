Release Notes
=============

Every time a Zotonic release is made, we create a document which lists
the most important changes. This page contains links to the release
notes for each release so far, dating back to Zotonic’s initial
release in November 2009.

.. toctree::
   :maxdepth: 1
   :glob:

   rel_*
