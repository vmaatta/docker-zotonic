
.. include:: meta-tinymce_remove.rst

Remove any tinyMCE controls from all textarea’s with the ``tinymce``
class in the target.


.. todo:: Extend documentation
