
.. include:: meta-admin_tasks.rst

Action module which provides postback handlers for the "status" view of the admin:

- Rebuild search index
- Flush cache
- Renumber categories  

.. todo:: Extend documentation
