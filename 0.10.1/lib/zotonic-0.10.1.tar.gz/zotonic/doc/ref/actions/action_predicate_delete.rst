
.. include:: meta-predicate_delete.rst

Delete a predicate, no confirmation.

.. todo:: Extend documentation
