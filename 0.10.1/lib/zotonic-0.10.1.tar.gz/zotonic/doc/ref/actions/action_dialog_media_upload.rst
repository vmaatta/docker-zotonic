
.. include:: meta-dialog_media_upload.rst

Shows the admin dialog for uploading a media item. See :ref:`manual-media`.

.. todo:: Extend documentation
