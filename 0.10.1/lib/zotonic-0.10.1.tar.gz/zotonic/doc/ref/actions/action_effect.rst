
.. include:: meta-effect.rst

Add a ``$(..).effect`` jQuery call to the target element.

.. todo:: Extend documentation
