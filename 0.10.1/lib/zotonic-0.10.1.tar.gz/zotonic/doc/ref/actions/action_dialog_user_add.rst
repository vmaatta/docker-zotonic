
.. include:: meta-dialog_user_add.rst

Show a dialog for adding a user. This creates a `person`
:term:`resource` and adds a username / password to it.

.. todo:: Extend documentation
