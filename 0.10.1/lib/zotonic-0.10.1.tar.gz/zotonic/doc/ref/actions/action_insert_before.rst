
.. include:: meta-insert_before.rst

Insert the result of a render action before an HTML element.

.. todo:: Extend documentation
