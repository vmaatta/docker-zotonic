
.. include:: meta-rest_rsc.rst

This controller implements a RESTful endpoint for :term:`resources <resource>` and its :ref:`model-rsc` model.

.. todo:: Extend documentation
