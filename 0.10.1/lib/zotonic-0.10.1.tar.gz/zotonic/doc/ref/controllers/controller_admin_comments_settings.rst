
.. include:: meta-admin_comments_settings.rst
             
Shows an admin settings screen where you can edit settings related to
:ref:`mod_comment`.
             
.. todo:: Extend documentation
