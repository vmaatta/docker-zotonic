
.. include:: meta-atom_feed_cat.rst

Renders an `Atom XML feed` based on the given :term:`category`.

.. todo:: Extend documentation
