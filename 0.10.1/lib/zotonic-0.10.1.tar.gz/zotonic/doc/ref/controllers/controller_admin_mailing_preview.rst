
.. include:: meta-admin_mailing_preview.rst

This controller shows a preview of what a resource that is being
mailed would look like, in a popup window.

.. todo:: Extend documentation
