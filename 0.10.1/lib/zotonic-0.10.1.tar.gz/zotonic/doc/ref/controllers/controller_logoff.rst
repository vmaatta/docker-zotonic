
.. include:: meta-logoff.rst

Controller that logs off a user, destroying the session. It also
removes any "remember me" cookies the user has, so that auto-logon is
disabled.

.. todo:: Extend documentation

.. seealso:: :ref:`controller-logon`, :ref:`manual-authentication`.
