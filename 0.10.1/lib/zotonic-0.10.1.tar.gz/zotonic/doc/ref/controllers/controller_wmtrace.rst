
.. include:: meta-wmtrace.rst

Admin controller which display traces of webmachine requests.

.. todo:: Extend documentation
