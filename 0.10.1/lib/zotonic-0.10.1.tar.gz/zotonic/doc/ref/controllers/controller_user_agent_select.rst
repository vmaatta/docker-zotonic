
.. include:: meta-user_agent_select.rst

Controller which changes the selected user agent preference for the
current session, by letting the user choose from a form or list of
links.

.. todo:: Extend documentation
