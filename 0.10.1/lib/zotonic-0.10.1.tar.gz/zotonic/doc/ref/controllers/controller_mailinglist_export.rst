
.. include:: meta-mailinglist_export.rst

Controller which downloads the given mailinglist id as a CSV file.

.. todo:: Extend documentation
