
.. include:: meta-admin_category_sorter.rst

Shows the admin category screen where you can edit the :term:`category` tree,
rearranging the categories, adding new categories, or removing
existing ones.
   
.. todo:: Extend documentation
