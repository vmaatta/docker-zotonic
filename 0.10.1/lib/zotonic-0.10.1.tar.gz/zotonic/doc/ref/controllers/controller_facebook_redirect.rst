
.. include:: meta-facebook_redirect.rst

Thic controller handles the OAuth redirect of the Facebook logon
handshake, when the user has authorized with Facebook and returns to
the site.

See http://developers.facebook.com/docs/authentication/

.. todo:: Extend documentation
