
.. include:: meta-admin_module_manager.rst

Shows the list of Zotonic modules currently known to the system.

The list is sorted based on the module’s status: active modules are
listed first, non-active modules next.

Each module has a button which let you toggle the active status of the
module.

.. todo:: Extend documentation
