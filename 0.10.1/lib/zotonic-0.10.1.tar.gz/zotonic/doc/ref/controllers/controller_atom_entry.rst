
.. include:: meta-atom_entry.rst

Renders a representation of the given :term:`resource` as Atom XML.

.. todo:: Extend documentation
