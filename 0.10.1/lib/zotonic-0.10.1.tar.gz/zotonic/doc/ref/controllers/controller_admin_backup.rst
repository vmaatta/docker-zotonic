
.. include:: meta-admin_backup.rst

Shows the admin backup screen where you can download nightly backups
that were made by :ref:`mod_backup`.
   
.. todo:: Extend documentation
