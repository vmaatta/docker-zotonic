
.. include:: meta-signup.rst

Controller which displays a form to sign up (rendered from ``signup.tpl``).

It also implements the nessecary postbacks to perform the signup and
log a user in.

.. todo:: Extend documentation
