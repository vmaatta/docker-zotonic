
.. include:: meta-oauth_apps.rst

Admin controller which shows an admin screen with the list of
currently registered OAuth apps (`consumers`).

Clicking an app shows the details of it: its name, tokens, and on a
second tab the permissions are listed that users that the app can get
once users authorize it.

.. todo:: Extend documentation
