
.. include:: meta-admin_referrers.rst

Shows the list of pages (:term:`resources <resource>`) which refer to
this :term:`resource` through an :term:`edge`.

.. todo:: Extend documentation
