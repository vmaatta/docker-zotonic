
.. include:: meta-twitter_redirect.rst

Thic controller handles the OAuth redirect of the Twitter logon
handshake, when the user has authorized with Twitter and returns to
the site.

.. todo:: Extend documentation
