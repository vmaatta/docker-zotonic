
.. include:: meta-admin_edit.rst

The main admin edit controller. This controller serves the edit page
where :term:`resources <resource>` can be edited.

.. image:: /img/admin_edit.png

             
.. todo:: Extend documentation

