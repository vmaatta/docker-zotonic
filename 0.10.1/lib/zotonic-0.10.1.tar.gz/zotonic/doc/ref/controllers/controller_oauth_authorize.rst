
.. include:: meta-oauth_authorize.rst

Controller implementing the `authorization` action in the OAuth 1.0
flow, which prompts the user to allow the application access to
certain :term:`services <service>`.

http://oauth.net/core/1.0/#auth_step2


.. todo:: Extend documentation
