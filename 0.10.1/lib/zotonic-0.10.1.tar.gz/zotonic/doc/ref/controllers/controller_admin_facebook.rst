
.. include:: meta-admin_facebook.rst

This controller shows the settings related to Facebook configuration.

.. todo:: Extend documentation
