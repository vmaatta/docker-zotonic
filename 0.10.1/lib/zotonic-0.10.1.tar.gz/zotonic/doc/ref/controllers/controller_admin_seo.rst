
.. include:: meta-admin_seo.rst

Shows a form with settings related to Search Engine Optimization.

.. todo:: Extend documentation
