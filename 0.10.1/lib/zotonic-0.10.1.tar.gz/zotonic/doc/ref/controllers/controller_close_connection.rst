
.. include:: meta-close_connection.rst

Closes the browser connection. Used primarily to work around an
apparent `Safari bug
<http://www.webmasterworld.com/macintosh_webmaster/3300569.htm>`_.

.. todo:: Extend documentation
