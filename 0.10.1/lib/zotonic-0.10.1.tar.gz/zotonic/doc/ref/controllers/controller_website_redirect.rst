
.. include:: meta-website_redirect.rst

This controller does a redirect to the ``website`` property of the
given :term:`resource`.

.. todo:: Extend documentation
