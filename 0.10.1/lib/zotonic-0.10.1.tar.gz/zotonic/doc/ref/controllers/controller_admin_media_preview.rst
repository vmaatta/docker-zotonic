
.. include:: meta-admin_media_preview.rst

A controller for rendering preview thumbnails of any media embedded in
a richtext-editor component of a :term:`resource` on the :ref:`admin
edit controller <controller-admin_edit>` page.

.. todo:: Extend documentation
