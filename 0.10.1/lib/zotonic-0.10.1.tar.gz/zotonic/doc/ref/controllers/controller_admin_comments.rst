
.. include:: meta-admin_comments.rst

Shows an admin screen with an overview of most recently created
comments. The screen offers the option to moderate the comments or
delete them entirely.

.. todo:: Extend documentation
