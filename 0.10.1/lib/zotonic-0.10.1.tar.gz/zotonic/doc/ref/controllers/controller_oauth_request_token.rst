
.. include:: meta-oauth_request_token.rst

Controller implementing the `request token` action in the OAuth 1.0
flow.

http://oauth.net/core/1.0/#auth_step1

.. todo:: Extend documentation
