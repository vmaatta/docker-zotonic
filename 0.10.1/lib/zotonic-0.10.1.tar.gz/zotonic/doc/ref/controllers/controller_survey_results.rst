
.. include:: meta-survey_results.rst

Controller which downloads a CSV file with the results of a survey.

.. todo:: Extend documentation
