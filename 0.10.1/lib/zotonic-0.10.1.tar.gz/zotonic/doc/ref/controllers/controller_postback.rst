
.. include:: meta-postback.rst

Controller which functions as the endpoint for :term:`postbacks <postback>`.

This controller is used internally by `wire` and `action`.

.. todo:: Extend documentation
