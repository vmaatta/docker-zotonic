
.. include:: meta-language_set.rst

Controller which sets the language as given in the ``code`` argument,
and redirects the user back to the page given in the ``p`` argument.

.. todo:: Extend documentation
