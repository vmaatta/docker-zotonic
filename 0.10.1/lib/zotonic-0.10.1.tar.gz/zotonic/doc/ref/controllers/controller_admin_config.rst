
.. include:: meta-admin_config.rst

Shows the admin config editor. Here you can edit the key/value pairs of :ref:`model-config`.

.. image:: /img/admin_config.png

.. todo:: Extend documentation
