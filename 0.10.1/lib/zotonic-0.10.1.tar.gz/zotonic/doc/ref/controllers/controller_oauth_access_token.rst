
.. include:: meta-oauth_access_token.rst

Controller implementing the `exchange request token for access token`
action in the OAuth 1.0 flow.

http://oauth.net/core/1.0/#auth_step3

.. todo:: Extend documentation
