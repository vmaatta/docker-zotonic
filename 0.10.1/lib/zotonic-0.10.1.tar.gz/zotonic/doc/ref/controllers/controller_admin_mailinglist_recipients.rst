
.. include:: meta-admin_mailinglist_recipients.rst

Shows the recipients of the current mailing list. The recipients are
listed in three columns, and have a checkbox next to them to
deactivate them.

Clicking a recipient shows a popup with information about the
recipient, where you can edit the e-mail address and the recipient’s
name details.

The page also offers buttons for importing and exporting lists of
email addresses.

.. todo:: Extend documentation
