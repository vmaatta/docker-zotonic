
.. include:: meta-facebook_authorize.rst

Controller which redirects the user to the authorize uri of Facebook,
to let the user login to the website with their Facebook account.

.. todo:: Extend documentation
