
.. include:: meta-admin_backup_revision.rst

Shows the admin backup revisions screen where you can see older
version for a :term:`resource`.
             
.. todo:: Extend documentation
