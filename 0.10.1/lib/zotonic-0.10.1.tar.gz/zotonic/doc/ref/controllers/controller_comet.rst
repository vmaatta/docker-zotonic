
.. include:: meta-comet.rst

Controller which is used by the :ref:`scomp-stream` tag which keeps a
connection open to the browser for browsers that do not support WebSockets, to use
long-polling as fallback.

.. todo:: Extend documentation
