
.. include:: meta-atom_feed_search.rst

Renders an `Atom XML feed` based on the given search terms.

For which search can be used, see the
:ref:`manual-datamodel-query-model` document.

.. todo:: Extend documentation
