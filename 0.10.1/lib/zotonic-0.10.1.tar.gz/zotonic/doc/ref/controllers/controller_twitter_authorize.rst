
.. include:: meta-twitter_authorize.rst

Controller which redirects the user to the authorize uri of Twitter,
to let the user login to the website with their Twitter account.

.. todo:: Extend documentation
