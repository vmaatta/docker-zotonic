
.. include:: meta-admin_mailinglist.rst

This controller shows the mailing lists that are available in the
system.

For each list, it shows the number of recipients and the
title. Clicking a list shows the :ref:`recipients
<controller-admin_mailinglist_recipients>` of the mailing list.

.. todo:: Extend documentation
