
.. include:: meta-wmtrace_conf.rst

Admin controller which let you configure and enable/disable the
display of traces of webmachine requests.

.. todo:: Extend documentation
