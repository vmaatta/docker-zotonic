
.. include:: meta-signup_confirm.rst

Controller which displays the confirmation page where the user can
confirm his signup.

The template used is ``signup_confirm.tpl``.

.. todo:: Extend documentation
