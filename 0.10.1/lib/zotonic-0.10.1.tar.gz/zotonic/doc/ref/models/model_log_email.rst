
.. include:: meta-log_email.rst

Not yet documented.
