
.. include:: meta-oauth_app.rst

Not yet documented.
