
.. include:: meta-session.rst

.. todo:: Not yet documented.


          



.. todo:: move this section somewhere?
                    
visitor / visitor_cookie
------------------------

Every visitor to a Zotonic web site gets a unique id. This id is
stored as a cookie on the user agent. When the visitor returns to the
site then he/she will be recognized by the cookie with the
visitor id. This enables the possibility to remember the visitor's
settings and preferences.

When a visitor logs on then the Zotonic can attach the user’s visitor
record to the user’s rsc record. Zotonic can then also merge multiple
visitor records into one. Enabling the possibility to remember
preference changes between different user agents.

