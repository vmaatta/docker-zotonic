
.. include:: meta-oauth_perms.rst

Not yet documented.
