
.. include:: meta-admin_blocks.rst

Not yet documented.
