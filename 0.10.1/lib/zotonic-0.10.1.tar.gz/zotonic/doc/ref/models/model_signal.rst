.. include:: meta-signal.rst

``m.signal``

Makes it possible to access the emitted signal in a template. 

``m.signal[signal].type`` - The type of the emitted signal