
.. include:: meta-l10n.rst

Not yet documented.
