
.. include:: meta-email_receive_recipient.rst

Not yet documented.
