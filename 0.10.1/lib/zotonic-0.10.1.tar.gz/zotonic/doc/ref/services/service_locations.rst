
.. include:: meta-locations.rst

Return a list of location :term:`resources <resource>` for the search
or id given.

