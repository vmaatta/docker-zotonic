
.. include:: meta-mod_base_site.rst

Implements the templates for a basic Zotonic site, built upon
:ref:`mod_bootstrap` framework.

This module contains templates for different device classes, so that
the site is also usable on simpler `text` or `phone` devices.
     
.. todo:: Add more documentation

.. seealso:: :ref:`dispatch rules <all-dispatch-mod_base_site>`, :ref:`mod_base`.
