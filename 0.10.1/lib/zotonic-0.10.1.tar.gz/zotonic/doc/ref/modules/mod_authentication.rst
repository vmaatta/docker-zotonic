
.. include:: meta-mod_authentication.rst

This module contains the main Zotonic authentication mechanism. It
contains the logon and logoff controllers, and implements the various
hooks as described in the :ref:`manual-auth` manual.
             
.. todo:: Add more documentation
