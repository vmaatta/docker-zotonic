
.. include:: meta-mod_contact.rst

Implements a basic contact form, which gets emailed to the
configuration value ``mod_contact.email``, when submitted.
             
.. todo:: Add more documentation
