
.. include:: meta-mod_bootstrap.rst

Adds support for the `Twitter Bootstrap
<http://twitter.github.com/bootstrap/>`_ CSS / Javascript framework.
             
.. todo:: Add more documentation
