
.. include:: meta-mod_admin_category.rst

Add support for editing :ref:`manual-datamodel-categories` in the
admin, by presenting an editable category tree.
             
.. note:: This module requires the presence of :ref:`mod_menu` for the
          required JavaScript files which make up the menu editor.

.. todo:: Add more documentation
