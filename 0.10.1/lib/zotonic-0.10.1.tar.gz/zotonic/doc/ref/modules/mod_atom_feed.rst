
.. include:: meta-mod_atom_feed.rst

Support for rendering feeds of Atom XML resources.
             
.. todo:: Add more documentation
