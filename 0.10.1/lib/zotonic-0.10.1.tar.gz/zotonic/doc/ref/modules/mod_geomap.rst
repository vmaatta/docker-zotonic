
.. include:: meta-mod_geomap.rst

Support for displaying maps and adding geographical locations to
:term:`resources <resource>` in the admin.

.. todo:: Add more documentation
