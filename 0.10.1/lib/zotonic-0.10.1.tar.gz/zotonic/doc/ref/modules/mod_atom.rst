
.. include:: meta-mod_atom.rst

Support for representing resources as Atom XML.
             
.. todo:: Add more documentation
