
.. include:: meta-mod_admin_stats.rst

The admin stats module adds a new admin page presenting a live view of
system statistics for things like number of requests, request
processing times, database and cache queries etc.
