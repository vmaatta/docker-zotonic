
.. include:: meta-mod_seo.rst

Adds basic search engine optimization to the base templates and
provides an admin interface for the SEO modules.
             
.. todo:: Add more documentation
