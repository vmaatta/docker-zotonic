
.. include:: meta-mod_email_receive.rst

Enables the Zotonic site to receive emails for the site’s users. The
user’s email address is `username@hostname`, where the hostname is the
hostname as configured in the :ref:`site’s config file <manual-site-anatomy>`.

Any email that has no valid recipient is rejected.

.. seealso:: :ref:`mod_email_relay`, :ref:`manual-email`.

.. todo:: Add more documentation
