
.. include:: meta-mod_l10n.rst

Localization of Zotonic. Provides lookups for country, month, week
names.
             
.. todo:: Add more documentation
