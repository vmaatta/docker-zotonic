.. _scomps:

Custom Tags
===========

Custom tags are internally called `scomp`, from `Screen COMPonents`.
Custom tags are implemented by :ref:`manual-modules`, so availability depends on the activated state of the corresponding module.

.. toctree::
   :maxdepth: 1
   :glob:

   scomp_*

