.. highlight:: django
.. include:: meta-inplace_textbox.rst

Render a JS-aided inplace textbox.

Example::

  {% inplace_textbox value="def.val." delegate="my_resource" hint="edit" %}

.. todo:: Improve documentation
            
