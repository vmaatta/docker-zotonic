
.. include:: meta-mod_custom_redirect-dispatch.rst

.. Not yet documented. (no todo item, as this is not a major issue)
