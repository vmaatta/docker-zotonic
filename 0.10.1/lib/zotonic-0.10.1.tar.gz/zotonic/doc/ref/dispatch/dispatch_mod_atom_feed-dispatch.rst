
.. include:: meta-mod_atom_feed-dispatch.rst

.. Not yet documented. (no todo item, as this is not a major issue)
