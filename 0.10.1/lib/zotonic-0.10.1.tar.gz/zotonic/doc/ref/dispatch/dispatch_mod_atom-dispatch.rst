
.. include:: meta-mod_atom-dispatch.rst

.. Not yet documented. (no todo item, as this is not a major issue)
