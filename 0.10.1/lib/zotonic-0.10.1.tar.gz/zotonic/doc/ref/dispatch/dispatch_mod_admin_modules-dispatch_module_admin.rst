
.. include:: meta-mod_admin_modules-dispatch_module_admin.rst

.. Not yet documented. (no todo item, as this is not a major issue)
