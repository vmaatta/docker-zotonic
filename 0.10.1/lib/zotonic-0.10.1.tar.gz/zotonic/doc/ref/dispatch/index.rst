All dispatch rules
==================

All the dispatch rules from all modules. For a background on dispatch rules, see :ref:`The URL dispatch system <manual-dispatch>`.

.. csv-table::
   :delim: tab
   :header: Name, Path, Resource, Args
   :file: meta-all-dispatch.csv

.. toctree::
   :hidden:
   :glob:

   dispatch_*
