#!/bin/sh
#
# This starts Zotonic in debug mode.  
#
# Zotonic will use the settings in priv/config
# Make your own by following the instructions in priv/config.in
#
# After it started you will be left in the Erlang shell.  
# Leave the shell with: ctrl-C crtl-C
#  
./bin/zotonic debug
