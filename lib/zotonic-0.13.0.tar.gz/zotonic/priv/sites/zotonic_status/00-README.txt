This is the Zotonic system site.  It can always be reached from any url.

It implements urls as defined by the modules_zotonic, it doesn't add any other functionality.
This site is always enabled and can still be used when all other sites are disabled or non-functional.
